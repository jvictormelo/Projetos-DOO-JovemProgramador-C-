public interface IPessoa{
string TipoUsuario{get;set;}
string Login{get;set;}

    void MostrarDados();
    bool CadastrarSenha(string senha);
    
}







