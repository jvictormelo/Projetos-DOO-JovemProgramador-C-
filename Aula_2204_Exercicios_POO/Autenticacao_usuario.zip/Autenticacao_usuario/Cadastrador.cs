public class Cadastrador:ICadastrador{

    public Boolean cadastrarUsuario(){

 string senha;
 int tamanhoMinimo = 8;
 bool contemNumero = false;
 Pessoa usuario = null;

 System.Console.WriteLine("\nEscolha o tipo de usuario:\n[1]: Admin \n[2]: Usuario \n[3]: Convidado");
 int usuarioEscolha = int.Parse(Console.ReadLine());

 switch(usuarioEscolha){
   
            case 1: 
                    usuario = new Admin();
                    usuario.TipoUsuario = "Admin";
                    break;
            case 2: 
                    usuario = new Usuario();
                    usuario.TipoUsuario = "Usuario";
                    break;
            case 3: 
                    usuario = new Convidado();
                    usuario.TipoUsuario = "Convidado";
                    break;
            default:

                System.Console.WriteLine("Escolha invalida, tente novamente!");
                
                return false;
        }

        System.Console.WriteLine("\nEntre com o Login: ");
         usuario.Login = Console.ReadLine();

        System.Console.WriteLine("Entre com a Senha");
         senha = Console.ReadLine();

        if (senha.Length >= tamanhoMinimo)
        {
            for (int i = 0; i < senha.Length; i++)
            {
                if(senha[i] >= '0' && senha [i]<='9'){
                    contemNumero = true;
                    break;

                }
            }
            if (contemNumero)
            {
                usuario.setSenha(senha);
                System.Console.WriteLine("Senha cadastrada com Sucesso!");
                usuario.MostrarDados();
                return true;
            }else{
                System.Console.WriteLine("A senha deve possuir ao menos 1 numero");
                return false;
            }
            
        }else{
            System.Console.WriteLine("ERRO: A SENHA TEM QUE POSSUIR NO MINIMO 8 CARACTERES");
            return false;
        }
    }




}









