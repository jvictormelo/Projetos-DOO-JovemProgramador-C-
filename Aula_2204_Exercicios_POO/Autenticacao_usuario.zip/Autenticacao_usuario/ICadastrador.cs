public interface ICadastrador {

bool cadastrarUsuario();

}