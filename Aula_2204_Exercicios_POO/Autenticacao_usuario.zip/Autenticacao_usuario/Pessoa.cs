public abstract class Pessoa{
public string TipoUsuario{get;set;}
public string Login{get;set;}
protected string Senha{get;set;}


 
public virtual void MostrarDados(){

System.Console.WriteLine($"\nTipo de Usuario: Ainda não foi cadastrado \nLogin: Ainda nao foi cadastrado");

}
   

public void setSenha(string senha){
this.Senha = senha;

}

}







