﻿
class Program{

static void Main(string[] args)
{
    ICadastrador cadastrador = new Cadastrador();
    cadastrador.cadastrarUsuario(); 
}


}


